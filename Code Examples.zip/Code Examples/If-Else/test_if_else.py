a = 5
b = 8

if a > b:
    print("a is greater than b")
    
if b > a:
    print("b is greater than a")
    
if a == b:
    print("a is equal to b")
    
    
    
if a > b:
    print("a is greater than b")
else:
    print("b is greater than a or a and b are equal")
    
    
    

if a > b:
    print("a is greater than b")
elif b > a:
    print("b is greater than a")
elif a == b:
    print("a is equal to b")