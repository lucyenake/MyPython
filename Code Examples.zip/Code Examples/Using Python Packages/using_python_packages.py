#import math as mt
import math
#from math import sin, cos
#from math import *

x = pi

y = sin(x)

print(y)

y = cos(x)

print(y)
