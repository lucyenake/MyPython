import numpy as np


temp_c = round(np.random.random()*20, 2)

print (temp_c)