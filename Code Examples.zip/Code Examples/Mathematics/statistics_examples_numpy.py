import numpy as np

data = [-1.0, 2.5, 3.25, 5.75]

#Mean or Average
m = np.mean(data)
print(m)

# Standard Deviation
st_dev = np.std(data)
print(st_dev)

# Median
med = np.median(data)
print(med)

# Minimum Value
minv = np.min(data)
print(minv)

# Maxumum Value
maxv = np.max(data)
print(maxv)