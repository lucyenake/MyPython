import numpy as np

p = [1, 0, 0, 2]

dpdx = np.polyder(p)

print(dpdx)