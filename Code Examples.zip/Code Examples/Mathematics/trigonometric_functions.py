import math as mt

x = 2*mt.pi

y = mt.sin(x)
print(y)

y = mt.cos(x)
print(y)

y = mt.tan(x)
print(y)
