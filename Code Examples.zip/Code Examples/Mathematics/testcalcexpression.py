import mymathfunctions as mymath

x = 2
y = 2

z = mymath.calcexpression(x,y)

print(z)