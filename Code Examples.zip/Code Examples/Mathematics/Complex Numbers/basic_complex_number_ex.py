a = 5 + 3j
b = 1 - 1j

c = a + b
print(c)

d = a - b
print(d)

e = a * b
print(e)

f = a / b
print(f)