import math as mt
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

y = mt.sin(3)

print(y)

plt.plot([1,2,3,4])
plt.xlabel('Time (s)')
plt.ylabel('Temperature (degC)')
plt.show()