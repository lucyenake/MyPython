import numpy as np


h = [4]

#h = np.zeros(4)

h[0] = 1.60
h[1] = 1.85
h[2] = 1.75
h[3] = 1.80