def average(x,y):
    
 return (x + y)/2

