def add(x,y):
    
 return x + y


x = 2
y = 5

z = add(x,y)

print(z)




add(2,3)


a = 4
b = 6
add(a,b)


answer = add(a,b)
