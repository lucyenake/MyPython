def c2f(Tc):
    
    Tf = (Tc * 9/5) + 32
    return Tf


def f2c(Tf):
    
    Tc = (Tf - 32)*(5/9)
    return Tc    
