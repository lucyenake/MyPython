from fahrenheit import c2f, f2c

Tc = 0

Tf = c2f(Tc)

print("Fahrenheit: " + str(Tf))


Tf = 32

Tc = f2c(Tf)

print("Celsius: " + str(Tc))