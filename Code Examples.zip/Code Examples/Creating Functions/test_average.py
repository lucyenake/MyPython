from myfunctions import average

a = 2
b = 3

c = average(a,b)

print(c)