class Car:
    model = "Volvo"
    color = "Blue"


car = Car()


print(car.model)
print(car.color)

