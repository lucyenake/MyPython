class Car:
  def __init__(self, model, color):
    self.model = model
    self.color = color

car1 = Car("Ford", "Green")

print(car1.model)
print(car1.color)


car2 = Car("Volvo", "Blue")

print(car2.model)
print(car2.color)