x = 1       # int
y = 2.8     # float
z = 3 + 2j   # complex


print(type(x))
print(type(y))
print(type(z))