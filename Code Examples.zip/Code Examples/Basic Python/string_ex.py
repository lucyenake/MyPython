a = "Hello World!"

print(a)

print(a[1])

print(a[2:5])

print(len(a))

print(a.lower())

print(a.upper())

print(a.replace("H", "J"))

print(a.split(" "))


print("Enter your name:")
x = input()
print("Hello, " + x)