f = open("myfile.txt", "x")

data = "Helo World"

f.write(data)

f.close()