import random
for x in range(10):
    data = random.randint(1,31)
    print(data)