data = [1.6, 3.4, 5.5, 9.4]

for x in data:
  print(x)
  
  
carlist = ["Volvo", "Tesla", "Ford"]

for car in carlist:
  print(car)



N = 10

for x in range(N):
  print(x)
  
  
  
start = 4
stop = 12 #but not including

for x in range(start, stop):
  print(x)
  
  
start = 4
stop = 12 #but not including
step = 2

for x in range(start, stop, step):
  print(x)
  
  

m = 8

while m > 2:
    print (m)
    m = m - 1