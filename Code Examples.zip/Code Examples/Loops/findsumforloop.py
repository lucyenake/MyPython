data = [1, 5, 6, 3, 12, 3]

sum = 0

#Find the Sum of all the numbers
for x in data:
  sum = sum + x
  
print(sum)



#Find the Mean or Average of all the numbers

N = len(data)

mean = sum/N

print(mean)