def makezeros(N):
    
    array = []
    
    for k in range(N):
        array.append(0)
    
    return array
 
