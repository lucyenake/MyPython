from math import *
from numpy import *

x = 3

y = sin(x)

print(y)


y = sin(x)

print(y)