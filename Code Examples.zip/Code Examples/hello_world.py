print("Hello")
print("World")
print("How are you?")